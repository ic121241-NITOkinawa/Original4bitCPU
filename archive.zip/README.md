# Original4bitCPU
Code for past CPU
I made 4bit CPU 2 years ago.
